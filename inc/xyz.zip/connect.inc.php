<?php
    //error_reporting(0);
	$con = new mysqli("localhost","id9722893_userdb","@Wjuy>yza3(Le!gh","id9722893_userdb");
	if($con->connect_error)
	{
		die("connection failed");
	}
?>